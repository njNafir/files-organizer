# File-Organizer

This application helps user to organize their messy directories or folders. Many times for many reason we download many files or etc
and by gradually these goes very messy. To get redemption from this problem this application comes into the picture. It continuosly listen
to a given directory for any extensions and when a file is present in the directory it automatically separate the file based on the extension.
In additional it creates folder of that extension and sub folders based on the current date.

Like a magic it organize all your files in a blink of an eye.

# Instructions

    python3 -m venv env

    . env/bin/activate

    pip install -r requirements.txt

    python files-organizer/simplegui.py